"use client";
import Link from "next/link";

export default function Home() {
  return (
    <>
      <header className="header">
        <div className="container header-content">
          <div className="logo">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="url(#paint0_linear)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M2 17L12 22L22 17" stroke="url(#paint1_linear)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M2 12L12 17L22 12" stroke="url(#paint2_linear)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <defs>
                <linearGradient id="paint0_linear" x1="2" y1="2" x2="22" y2="12" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#00d2ff" />
                  <stop offset="1" stopColor="#3a7bd5" />
                </linearGradient>
                <linearGradient id="paint1_linear" x1="2" y1="17" x2="22" y2="22" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#00d2ff" />
                  <stop offset="1" stopColor="#3a7bd5" />
                </linearGradient>
                <linearGradient id="paint2_linear" x1="2" y1="12" x2="22" y2="17" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#00d2ff" />
                  <stop offset="1" stopColor="#3a7bd5" />
                </linearGradient>
              </defs>
            </svg>
            HalalData
          </div>
          <nav className="nav-links">
            <Link href="#features">Features</Link>
            <Link href="#api">API</Link>
            <Link href="#pricing">Pricing</Link>
          </nav>
          <div style={{ display: 'flex', gap: '1rem' }}>
            <Link href="/login" className="btn btn-outline">Log in</Link>
            <Link href="/dashboard" className="btn btn-primary">Dashboard</Link>
          </div>
        </div>
      </header>

      <main>
        <section className="hero">
          <div className="container">
            <div className="hero-badge">Sharia Compliant Data Layer</div>
            <h1>The Gold Standard for<br /><span>Halal Crypto Indices</span></h1>
            <p>
              Integrate verified, real-time Halal cryptocurrency data into your platforms seamlessly. 
              Our enterprise-grade API powers the next generation of Islamic finance applications.
            </p>
            
            {/* PUBLIC COIN CHECKER (STEP 8) */}
            <div className="glass-panel" style={{ maxWidth: '600px', margin: '3rem auto', padding: '2rem' }}>
              <h3 style={{ fontSize: '1.2rem', marginBottom: '1rem' }}>Check any coin instantly</h3>
              <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '1.5rem' }}>
                <input 
                  type="text" 
                  placeholder="Enter coin name or ticker (e.g. BTC, Solana)" 
                  style={{ flex: 1, padding: '1rem', borderRadius: '8px', border: '1px solid var(--color-border)', background: 'rgba(0,0,0,0.4)', color: '#fff', fontSize: '1rem', outline: 'none' }}
                />
                <button className="btn btn-primary" onClick={() => alert("Basic Verdict: ⚠️ Doubtful\n\n(Mocked response. In production, this calls a public endpoint with IP rate-limiting).")} style={{ padding: '0 2rem' }}>Check</button>
              </div>
              <div style={{ padding: '1rem', background: 'rgba(255,255,255,0.05)', borderRadius: '8px', textAlign: 'center' }}>
                <p style={{ fontSize: '0.9rem', color: 'var(--color-text-muted)', marginBottom: '0.5rem' }}>
                  See full Sharia analysis, scoring breakdown, and PDF report &rarr;
                </p>
                <Link href="/signup" style={{ color: 'var(--color-primary)', fontWeight: 'bold' }}>Sign up free</Link>
              </div>
            </div>

          </div>
        </section>

        <section id="features" className="features container">
          <h2 className="section-title">Built for Modern Platforms</h2>
          <div className="grid">
            <div className="feature-card glass-panel">
              <div className="feature-icon">🔍</div>
              <h3>Rigorous Screening</h3>
              <p>Every asset in our index undergoes strict screening for Sharia compliance by Islamic finance scholars.</p>
            </div>
            <div className="feature-card glass-panel">
              <div className="feature-icon">⚡</div>
              <h3>Ultra-Fast API</h3>
              <p>Built on top of a highly optimized global edge network, delivering data with sub-10ms latency.</p>
            </div>
            <div className="feature-card glass-panel">
              <div className="feature-icon">🔒</div>
              <h3>Enterprise Security</h3>
              <p>Secure API key management with granular permissions and detailed usage analytics.</p>
            </div>
          </div>
        </section>

        <section id="api" className="demo-section">
          <div className="container">
            <h2 className="section-title">Developer-First Experience</h2>
            <div className="glass-panel" style={{ maxWidth: '800px', margin: '0 auto', overflow: 'hidden' }}>
              <div style={{ background: 'rgba(0,0,0,0.5)', padding: '1rem', borderBottom: '1px solid rgba(255,255,255,0.1)', display: 'flex', gap: '0.5rem' }}>
                <div style={{ width: '12px', height: '12px', borderRadius: '50%', background: '#ff5f56' }}></div>
                <div style={{ width: '12px', height: '12px', borderRadius: '50%', background: '#ffbd2e' }}></div>
                <div style={{ width: '12px', height: '12px', borderRadius: '50%', background: '#27c93f' }}></div>
              </div>
              <div className="code-block">
<pre><code><span className="code-comment">// Fetch the top 10 Halal cryptocurrencies</span>
<span className="code-keyword">const</span> response = <span className="code-keyword">await</span> <span className="code-function">fetch</span>(<span className="code-string">"https://api.halaldata.com/v1/indices/top"</span>, {"{"}
  headers: {"{"}
    <span className="code-string">"Authorization"</span>: <span className="code-string">"Bearer YOUR_API_KEY"</span>
  {"}"}
{"}"});

<span className="code-keyword">const</span> data = <span className="code-keyword">await</span> response.<span className="code-function">json</span>();
<span className="code-function">console</span>.<span className="code-function">log</span>(data.assets);
<span className="code-comment">// Output: [{"{"} symbol: "BTC", status: "compliant" {"}"}, ...]</span>
</code></pre>
              </div>
            </div>
          </div>
        </section>

        <section id="pricing" className="features container">
          <h2 className="section-title">Transparent Pricing</h2>
          <div className="grid">
            <div className="feature-card glass-panel pricing-card">
              <h3>Developer</h3>
              <div className="price">$0<span>/mo</span></div>
              <p>Perfect for testing and small projects.</p>
              <ul className="pricing-features">
                <li>10,000 requests / month</li>
                <li>Daily data updates</li>
                <li>Community support</li>
              </ul>
              <button className="btn btn-outline" style={{ width: '100%' }}>Start Free</button>
            </div>
            <div className="feature-card glass-panel pricing-card" style={{ transform: 'scale(1.05)', borderColor: 'var(--color-primary)' }}>
              <div style={{ position: 'absolute', top: 0, left: '50%', transform: 'translate(-50%, -50%)', background: 'var(--color-primary)', color: '#000', padding: '0.2rem 1rem', borderRadius: '12px', fontSize: '0.8rem', fontWeight: 'bold' }}>MOST POPULAR</div>
              <h3>Pro Platform</h3>
              <div className="price">$99<span>/mo</span></div>
              <p>For growing platforms and exchanges.</p>
              <ul className="pricing-features">
                <li>1,000,000 requests / month</li>
                <li>Real-time data updates</li>
                <li>Priority email support</li>
                <li>Historical data access</li>
              </ul>
              <button className="btn btn-primary" style={{ width: '100%' }}>Subscribe Now</button>
            </div>
            <div className="feature-card glass-panel pricing-card">
              <h3>Enterprise</h3>
              <div className="price">Custom</div>
              <p>For large-scale institutional needs.</p>
              <ul className="pricing-features">
                <li>Unlimited requests</li>
                <li>Dedicated account manager</li>
                <li>Custom SLA</li>
                <li>On-premise deployment options</li>
              </ul>
              <button className="btn btn-outline" style={{ width: '100%' }}>Contact Sales</button>
            </div>
          </div>
        </section>
      </main>

      <footer className="footer container">
        <p>© 2026 HalalData. All rights reserved.</p>
        <p style={{ marginTop: '0.5rem', fontSize: '0.85rem' }}>Providing Sharia-compliant digital asset data for the modern web.</p>
      </footer>
    </>
  );
}
