"use client";

import { useState } from 'react';
import { supabase } from '../../lib/supabase';
import Link from 'next/link';

export default function ForgotPassword() {
  const [email, setEmail] = useState('');
  const [msg, setMsg] = useState('');

  const handleReset = async (e: React.FormEvent) => {
    e.preventDefault();
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/dashboard`,
    });
    if (error) {
      setMsg(error.message);
    } else {
      setMsg('Check your email for the reset link.');
    }
  };

  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh', background: 'var(--color-bg)' }}>
      <div className="glass-panel" style={{ width: '100%', maxWidth: '400px', padding: '3rem 2rem', textAlign: 'center' }}>
        <h1 style={{ fontSize: '1.5rem', marginBottom: '1rem' }}>Reset Password</h1>
        <p style={{ color: 'var(--color-text-muted)', marginBottom: '2rem' }}>Enter your email to receive a password reset link.</p>
        
        <form onSubmit={handleReset} style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem', textAlign: 'left' }}>
          <div>
            <label style={{ display: 'block', marginBottom: '0.5rem', fontSize: '0.9rem', color: 'var(--color-text-muted)' }}>Email Address</label>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)} required style={{ width: '100%', padding: '0.8rem 1rem', borderRadius: '8px', border: '1px solid var(--color-border)', background: 'rgba(0,0,0,0.2)', color: 'var(--color-text-main)', outline: 'none' }} />
          </div>
          {msg && <div style={{ color: 'var(--color-primary)', fontSize: '0.9rem' }}>{msg}</div>}
          <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '1rem', textAlign: 'center' }}>
            Send Reset Link
          </button>
        </form>
        
        <p style={{ marginTop: '2rem', fontSize: '0.9rem', color: 'var(--color-text-muted)' }}>
          <Link href="/login" style={{ color: 'var(--color-primary)' }}>Back to Login</Link>
        </p>
      </div>
    </div>
  );
}
