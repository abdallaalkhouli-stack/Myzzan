"use client";

import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

export default function Dashboard() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [tier, setTier] = useState<string>('FREE');
  const [apiKey, setApiKey] = useState<string>('');
  const [showKey, setShowKey] = useState(false);
  const [usage, setUsage] = useState({ used: 0, limit: 10 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadData() {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        router.push('/login');
        return;
      }
      
      setUser(session.user);

      // Fetch user tier and API key
      const { data: uData } = await supabase.from('users').select('tier').eq('id', session.user.id).single();
      if (uData) setTier(uData.tier);

      const { data: keyData } = await supabase.from('api_keys').select('*').eq('user_id', session.user.id).single();
      if (keyData) {
        setApiKey(keyData.key_hash);
        setUsage({ used: keyData.calls_today, limit: keyData.limit_per_day });
      }

      setLoading(false);
    }
    loadData();
  }, [router]);

  const handleSignout = async () => {
    await supabase.auth.signOut();
    router.push('/login');
  };

  const handleRegenerate = async () => {
    if (!confirm('Are you sure? Your old API key will stop working immediately.')) return;
    const newKey = 'sk_live_' + Math.random().toString(36).substr(2, 9) + Math.random().toString(36).substr(2, 9);
    
    await supabase.from('api_keys').update({ key_hash: newKey }).eq('user_id', user.id);
    setApiKey(newKey);
    alert('API Key regenerated successfully.');
  };

  if (loading) return <div style={{ textAlign: 'center', padding: '4rem', color: '#fff' }}>Loading...</div>;

  const maskedKey = apiKey ? `${apiKey.substring(0, 10)}****${apiKey.substring(apiKey.length - 4)}` : 'No API Key generated';

  return (
    <>
      <header className="header">
        <div className="container header-content">
          <Link href="/" className="logo">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="url(#paint0_linear)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M2 17L12 22L22 17" stroke="url(#paint1_linear)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M2 12L12 17L22 12" stroke="url(#paint2_linear)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            HalalData
          </Link>
          <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
            <span style={{ color: 'var(--color-text-muted)' }}>{user?.email}</span>
            <button onClick={handleSignout} className="btn btn-outline" style={{ padding: '0.4rem 1rem' }}>Sign out</button>
          </div>
        </div>
      </header>

      <main className="container" style={{ paddingTop: '4rem', paddingBottom: '4rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
          <h1 style={{ fontSize: '2.5rem' }}>Welcome back!</h1>
          {tier === 'ENTERPRISE' && <span style={{ background: '#3a7bd5', padding: '0.5rem 1rem', borderRadius: '8px', fontWeight: 'bold' }}>Enterprise Account</span>}
          {tier === 'PRO' && <span style={{ background: 'var(--color-primary)', color: '#000', padding: '0.5rem 1rem', borderRadius: '8px', fontWeight: 'bold' }}>Pro Account</span>}
          {tier === 'FREE' && <span style={{ background: 'rgba(255,255,255,0.1)', padding: '0.5rem 1rem', borderRadius: '8px', fontWeight: 'bold' }}>Free Tier</span>}
        </div>
        
        <div className="grid">
          <div className="glass-panel" style={{ padding: '2rem' }}>
            <h2 style={{ fontSize: '1.25rem', marginBottom: '1.5rem', color: 'var(--color-text-muted)' }}>Your API Key</h2>
            {tier === 'FREE' ? (
              <div style={{ padding: '1rem', background: 'rgba(255,0,0,0.1)', borderRadius: '8px', color: '#ff7b72' }}>
                API Keys are only available on PRO or ENTERPRISE plans.
              </div>
            ) : (
              <>
                <div style={{ display: 'flex', gap: '1rem', alignItems: 'center', background: 'rgba(0,0,0,0.3)', padding: '1rem', borderRadius: '8px', border: '1px solid var(--color-border)' }}>
                  <code style={{ flex: 1, fontFamily: 'var(--font-mono)', fontSize: '1.1rem', color: 'var(--color-primary)' }}>
                    {showKey ? apiKey : maskedKey}
                  </code>
                  <button onClick={() => setShowKey(!showKey)} className="btn btn-outline" style={{ padding: '0.5rem 1rem' }}>
                    {showKey ? 'Hide' : 'Reveal'}
                  </button>
                </div>
                <div style={{ marginTop: '1rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <p style={{ fontSize: '0.9rem', color: 'var(--color-text-muted)' }}>
                    Keep this key secret. Do not expose it in client-side code.
                  </p>
                  <button onClick={handleRegenerate} style={{ background: 'none', border: 'none', color: '#ff7b72', cursor: 'pointer', textDecoration: 'underline' }}>Regenerate Key</button>
                </div>
              </>
            )}
          </div>

          <div className="glass-panel" style={{ padding: '2rem' }}>
            <h2 style={{ fontSize: '1.25rem', marginBottom: '1.5rem', color: 'var(--color-text-muted)' }}>Usage Today</h2>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: '1rem' }}>
              <div>
                <div style={{ fontSize: '3rem', fontWeight: 'bold', lineHeight: '1' }}>{usage.used}</div>
                <div style={{ color: 'var(--color-text-muted)', marginTop: '0.5rem' }}>Requests today</div>
              </div>
              <div style={{ color: 'var(--color-success)', fontWeight: '600' }}>
                {usage.limit > 1000000 ? 'Unlimited' : `${usage.limit} Limit`}
              </div>
            </div>
            {usage.limit < 1000000 && (
              <div style={{ width: '100%', height: '8px', background: 'rgba(255,255,255,0.1)', borderRadius: '4px', overflow: 'hidden' }}>
                <div style={{ width: `${Math.min(100, (usage.used / usage.limit) * 100)}%`, height: '100%', background: 'var(--color-primary)' }}></div>
              </div>
            )}
          </div>
        </div>

        {tier === 'FREE' && (
          <div className="glass-panel" style={{ padding: '2rem', marginTop: '2rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: 'linear-gradient(135deg, rgba(58, 123, 213, 0.2), rgba(0, 210, 255, 0.2))' }}>
            <div>
              <h2 style={{ fontSize: '1.5rem', marginBottom: '0.5rem' }}>Upgrade to PRO</h2>
              <p style={{ color: 'var(--color-text-muted)' }}>Get a personal API key, unlimited coin checks, and PDF reports.</p>
            </div>
            <Link href="/pricing" className="btn btn-primary" style={{ padding: '1rem 2rem' }}>View Pricing</Link>
          </div>
        )}

        <div className="glass-panel" style={{ padding: '2rem', marginTop: '2rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div>
              <h3 style={{ fontSize: '1.5rem', marginBottom: '0.5rem' }}>Explore the AI Sharia Engine</h3>
              <p style={{ color: 'var(--color-text-muted)' }}>Browse the top 50 cryptocurrencies and their Sharia compliance verdicts.</p>
            </div>
            <Link href="/dashboard/coins" className="btn btn-primary">
              Open Coins Dashboard
            </Link>
          </div>
        </div>
      </main>
    </>
  );
}
