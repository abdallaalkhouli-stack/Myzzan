"use client";

import { useEffect, useState } from 'react';
import Link from 'next/link';

export default function CoinsDashboard() {
  const [coins, setCoins] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('All'); // All, halal, haram, doubtful
  const [sort, setSort] = useState('market_cap'); // market_cap, status, confidence

  useEffect(() => {
    async function fetchCoins() {
      try {
        const res = await fetch('/api/v1/indices/halal', {
          headers: {
            'Authorization': 'Bearer sk_live_halal_8f92a4c10eb3d45f'
          }
        });
        const data = await res.json();
        if (data.success) {
          setCoins(data.data.assets);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    fetchCoins();
  }, []);

  // Derived state for filtering and sorting
  const filteredCoins = coins.filter(c => {
    if (filter === 'All') return true;
    return c.sharia_analysis.status === filter.toLowerCase();
  });

  const sortedCoins = [...filteredCoins].sort((a, b) => {
    if (sort === 'market_cap') {
      return b.market_cap - a.market_cap; // Descending
    }
    if (sort === 'status') {
      return a.sharia_analysis.status.localeCompare(b.sharia_analysis.status);
    }
    if (sort === 'confidence') {
      const confMap: any = { "high": 3, "medium": 2, "low": 1 };
      return confMap[b.sharia_analysis.confidence] - confMap[a.sharia_analysis.confidence];
    }
    return 0;
  });

  const formatCurrency = (val: number) => {
    if (val >= 1e9) return `$${(val / 1e9).toFixed(2)}B`;
    if (val >= 1e6) return `$${(val / 1e6).toFixed(2)}M`;
    return `$${val.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 6 })}`;
  };

  const getStatusColor = (status: string) => {
    if (status === 'halal') return '#10b981'; // Green
    if (status === 'haram') return '#ef4444'; // Red
    return '#f59e0b'; // Yellow/Orange
  };

  const handleBulkExport = async () => {
    try {
      const html2canvas = (await import('html2canvas')).default;
      const { jsPDF } = await import('jspdf');
      
      const element = document.getElementById('coins-table');
      if (!element) return;
      
      const canvas = await html2canvas(element, { scale: 1.5 });
      const imgData = canvas.toDataURL('image/png');
      
      const pdf = new jsPDF('l', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
      
      pdf.setFontSize(20);
      pdf.text("HalalData Enterprise - Full 50 Coin Sharia Report", 14, 20);
      
      pdf.addImage(imgData, 'PNG', 0, 30, pdfWidth, pdfHeight);
      pdf.save(`HalalData_Enterprise_Bulk_Report.pdf`);
    } catch (err) {
      console.error(err);
      alert('Error generating bulk PDF report.');
    }
  };

  return (
    <div className="container" style={{ paddingTop: '4rem', paddingBottom: '4rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
        <h1 style={{ fontSize: '2.5rem' }}>Coins Dashboard</h1>
        <div style={{ display: 'flex', gap: '1rem' }}>
          <button onClick={handleBulkExport} className="btn btn-primary" style={{ background: '#3a7bd5' }}>Export Full 50-Coin Report (Enterprise)</button>
          <Link href="/dashboard" className="btn btn-outline">Back to API</Link>
        </div>
      </div>

      <div className="glass-panel" style={{ padding: '1.5rem', marginBottom: '2rem', display: 'flex', gap: '2rem', flexWrap: 'wrap' }}>
        <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
          <span style={{ color: 'var(--color-text-muted)' }}>Filter:</span>
          <select 
            value={filter} 
            onChange={e => setFilter(e.target.value)}
            style={{ background: 'rgba(0,0,0,0.3)', color: '#fff', padding: '0.5rem 1rem', borderRadius: '8px', border: '1px solid var(--color-border)', outline: 'none' }}
          >
            <option value="All">All Coins</option>
            <option value="halal">Halal Only</option>
            <option value="doubtful">Doubtful</option>
            <option value="haram">Haram</option>
          </select>
        </div>
        <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
          <span style={{ color: 'var(--color-text-muted)' }}>Sort by:</span>
          <select 
            value={sort} 
            onChange={e => setSort(e.target.value)}
            style={{ background: 'rgba(0,0,0,0.3)', color: '#fff', padding: '0.5rem 1rem', borderRadius: '8px', border: '1px solid var(--color-border)', outline: 'none' }}
          >
            <option value="market_cap">Market Cap (Highest)</option>
            <option value="status">Halal Status</option>
            <option value="confidence">Confidence Score</option>
          </select>
        </div>
      </div>

      {loading ? (
        <div style={{ textAlign: 'center', padding: '4rem', color: 'var(--color-text-muted)' }}>Loading AI Analysis...</div>
      ) : (
        <div className="glass-panel" style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid var(--color-border)', color: 'var(--color-text-muted)' }}>
                <th style={{ padding: '1rem 1.5rem' }}>Asset</th>
                <th style={{ padding: '1rem 1.5rem' }}>Price</th>
                <th style={{ padding: '1rem 1.5rem' }}>Market Cap</th>
                <th style={{ padding: '1rem 1.5rem' }}>Status</th>
                <th style={{ padding: '1rem 1.5rem' }}>Confidence</th>
                <th style={{ padding: '1rem 1.5rem' }}>Certified By</th>
                <th style={{ padding: '1rem 1.5rem' }}>Action</th>
              </tr>
            </thead>
            <tbody>
              {sortedCoins.map((coin) => (
                <tr key={coin.id} style={{ borderBottom: '1px solid var(--color-border)' }}>
                  <td style={{ padding: '1rem 1.5rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
                    <img src={coin.image} alt={coin.name} width={32} height={32} style={{ borderRadius: '50%' }} />
                    <div>
                      <div style={{ fontWeight: 'bold' }}>{coin.name}</div>
                      <div style={{ fontSize: '0.8rem', color: 'var(--color-text-muted)' }}>{coin.symbol}</div>
                    </div>
                  </td>
                  <td style={{ padding: '1rem 1.5rem' }}>
                    {formatCurrency(coin.current_price)}
                    <div style={{ fontSize: '0.8rem', color: coin.price_change_percentage_24h >= 0 ? 'var(--color-success)' : '#ef4444' }}>
                      {coin.price_change_percentage_24h > 0 ? '+' : ''}{coin.price_change_percentage_24h.toFixed(2)}%
                    </div>
                  </td>
                  <td style={{ padding: '1rem 1.5rem' }}>{formatCurrency(coin.market_cap)}</td>
                  <td style={{ padding: '1rem 1.5rem' }}>
                    <span style={{ 
                      display: 'inline-block', padding: '0.3rem 0.8rem', borderRadius: '12px', fontSize: '0.8rem', fontWeight: 'bold', textTransform: 'uppercase',
                      background: `${getStatusColor(coin.sharia_analysis.status)}20`,
                      color: getStatusColor(coin.sharia_analysis.status),
                      border: `1px solid ${getStatusColor(coin.sharia_analysis.status)}40`
                    }}>
                      {coin.sharia_analysis.status}
                    </span>
                  </td>
                  <td style={{ padding: '1rem 1.5rem', textTransform: 'capitalize' }}>{coin.sharia_analysis.confidence}</td>
                  <td style={{ padding: '1rem 1.5rem', color: 'var(--color-text-muted)', fontSize: '0.9rem' }}>
                    {coin.sharia_analysis.certified_by || 'Pending AI/Scholar Review'}
                  </td>
                  <td style={{ padding: '1rem 1.5rem' }}>
                    <Link href={`/dashboard/coins/${coin.symbol.toLowerCase()}`} className="btn btn-outline" style={{ padding: '0.4rem 1rem', fontSize: '0.85rem' }}>
                      Details
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {sortedCoins.length === 0 && (
            <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--color-text-muted)' }}>No coins matched the selected filters.</div>
          )}
        </div>
      )}
    </div>
  );
}
