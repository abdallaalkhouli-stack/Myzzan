"use client";

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useParams } from 'next/navigation';

export default function CoinDetail() {
  const params = useParams();
  const ticker = params.ticker as string;
  const [coin, setCoin] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchCoin() {
      try {
        const res = await fetch('/api/v1/indices/halal', {
          headers: {
            'Authorization': 'Bearer sk_live_halal_8f92a4c10eb3d45f'
          }
        });
        const data = await res.json();
        if (data.success) {
          const found = data.data.assets.find((c: any) => c.symbol.toLowerCase() === ticker.toLowerCase());
          setCoin(found);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    fetchCoin();
  }, [ticker]);

  const getStatusColor = (status: string) => {
    if (status === 'halal') return '#10b981';
    if (status === 'haram') return '#ef4444';
    return '#f59e0b';
  };

  const shariaCriteriaList = [
    { key: "riba", label: "No Riba (Interest)" },
    { key: "gharar", label: "No Gharar (Excessive Speculation)" },
    { key: "maysir", label: "No Maysir (Gambling)" },
    { key: "haram_industry", label: "No Haram Industry Exposure" },
    { key: "utility", label: "Real Utility / Asset Backing" },
    { key: "transparency", label: "Transparent & Auditable" }
  ];

  // Derive mock pass/fail checklist based on the status
  const getCriterionStatus = (key: string, status: string) => {
    if (status === 'halal') return true;
    if (status === 'haram') {
      if (key === 'utility' || key === 'gharar') return false; 
      return true; // For memecoins mostly it's utility/gharar
    }
    if (status === 'doubtful') {
      if (key === 'riba' || key === 'gharar') return null; // Unsure
      return true;
    }
    return true;
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    alert('Link copied to clipboard!');
  };

  const handleDownloadPDF = async () => {
    // Check if user is PRO or ENTERPRISE in a real app
    // Here we just generate the PDF
    try {
      const html2canvas = (await import('html2canvas')).default;
      const { jsPDF } = await import('jspdf');
      
      const element = document.getElementById('pdf-content');
      if (!element) return;
      
      const canvas = await html2canvas(element, { scale: 2 });
      const imgData = canvas.toDataURL('image/png');
      
      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
      
      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      pdf.save(`${coin.name}_Sharia_Report.pdf`);
    } catch (err) {
      console.error(err);
      alert('Error generating PDF report.');
    }
  };

  if (loading) return <div className="container" style={{ paddingTop: '4rem', textAlign: 'center' }}>Analyzing via AI Sharia Engine...</div>;
  if (!coin) return <div className="container" style={{ paddingTop: '4rem', textAlign: 'center' }}>Coin not found in top 50 index.</div>;

  const analysis = coin.sharia_analysis;
  const statusColor = getStatusColor(analysis.status);

  return (
    <div className="container" style={{ paddingTop: '4rem', paddingBottom: '4rem' }}>
      <div style={{ marginBottom: '2rem', display: 'flex', justifyContent: 'space-between' }}>
        <Link href="/dashboard/coins" style={{ color: 'var(--color-primary)', textDecoration: 'none' }}>&larr; Back to Dashboard</Link>
        <button onClick={handleDownloadPDF} className="btn btn-primary" style={{ padding: '0.4rem 1rem' }}>Download PDF Report</button>
      </div>

      <div id="pdf-content" style={{ background: 'var(--color-bg)', padding: '2rem', borderRadius: '16px' }}>
        <div style={{ textAlign: 'center', marginBottom: '2rem', borderBottom: '1px solid var(--color-border)', paddingBottom: '2rem' }}>
          <h2 style={{ fontSize: '2rem', color: 'var(--color-primary)' }}>HalalData</h2>
          <h3>Sharia Compliance Report</h3>
          <p style={{ color: 'var(--color-text-muted)' }}>Generated on: {new Date().toLocaleString()}</p>
        </div>

        <div className="grid" style={{ gridTemplateColumns: '1fr 2fr', gap: '2rem' }}>
        {/* LEFT COLUMN: Summary & Verdict */}
        <div>
          <div className="glass-panel" style={{ padding: '2rem', textAlign: 'center', position: 'relative' }}>
            <img src={coin.image} alt={coin.name} width={80} height={80} style={{ borderRadius: '50%', marginBottom: '1rem' }} />
            <h1 style={{ fontSize: '2rem', marginBottom: '0.2rem' }}>{coin.name}</h1>
            <div style={{ color: 'var(--color-text-muted)', fontSize: '1.2rem', marginBottom: '1.5rem' }}>{coin.symbol}</div>
            
            <div style={{ 
              display: 'inline-block', padding: '0.6rem 1.5rem', borderRadius: '20px', fontSize: '1.2rem', fontWeight: 'bold', textTransform: 'uppercase',
              background: `${statusColor}20`, color: statusColor, border: `2px solid ${statusColor}`
            }}>
              {analysis.status}
            </div>

            <div style={{ marginTop: '2rem', textAlign: 'left' }}>
              <div style={{ marginBottom: '1rem' }}>
                <span style={{ color: 'var(--color-text-muted)', fontSize: '0.9rem' }}>Confidence Level</span>
                <div style={{ fontWeight: 'bold', textTransform: 'capitalize' }}>{analysis.confidence}</div>
              </div>
              <div style={{ marginBottom: '1rem' }}>
                <span style={{ color: 'var(--color-text-muted)', fontSize: '0.9rem' }}>Certified By</span>
                <div style={{ fontWeight: 'bold' }}>{analysis.certified_by || 'Uncertified / Requires Independent Review'}</div>
              </div>
              <div style={{ marginBottom: '1rem' }}>
                <span style={{ color: 'var(--color-text-muted)', fontSize: '0.9rem' }}>Current Price</span>
                <div style={{ fontWeight: 'bold' }}>${coin.current_price.toLocaleString()}</div>
              </div>
            </div>

            <button onClick={handleShare} className="btn btn-outline" style={{ width: '100%', marginTop: '1rem' }}>
              Share Verdict
            </button>
          </div>
        </div>

        {/* RIGHT COLUMN: Deep Dive Analysis */}
        <div>
          <div className="glass-panel" style={{ padding: '2rem', marginBottom: '2rem' }}>
            <h2 style={{ fontSize: '1.5rem', marginBottom: '1.5rem' }}>AI Verdict Breakdown</h2>
            <ul style={{ listStyle: 'none', padding: 0 }}>
              {analysis.reasoning.map((reason: string, i: number) => (
                <li key={i} style={{ marginBottom: '1rem', display: 'flex', gap: '1rem', alignItems: 'flex-start' }}>
                  <span style={{ color: 'var(--color-primary)', fontWeight: 'bold' }}>&rarr;</span>
                  <span style={{ lineHeight: '1.5' }}>{reason}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="glass-panel" style={{ padding: '2rem' }}>
            <h2 style={{ fontSize: '1.5rem', marginBottom: '1.5rem' }}>Sharia Criteria Checklist</h2>
            <div style={{ display: 'grid', gap: '1rem' }}>
              {shariaCriteriaList.map(item => {
                const pass = getCriterionStatus(item.key, analysis.status);
                return (
                  <div key={item.key} style={{ display: 'flex', justifyContent: 'space-between', padding: '1rem', background: 'rgba(0,0,0,0.2)', borderRadius: '8px', border: '1px solid var(--color-border)' }}>
                    <span>{item.label}</span>
                    <span>
                      {pass === true && <span style={{ color: 'var(--color-success)', fontWeight: 'bold' }}>✓ Pass</span>}
                      {pass === false && <span style={{ color: '#ef4444', fontWeight: 'bold' }}>✗ Fail</span>}
                      {pass === null && <span style={{ color: 'var(--color-text-muted)', fontWeight: 'bold' }}>? Review Needed</span>}
                    </span>
                  </div>
                );
              })}
            </div>
            <p style={{ marginTop: '1.5rem', fontSize: '0.85rem', color: 'var(--color-text-muted)' }}>
              Disclaimer: This checklist is generated by our AI Sharia Engine and should not be taken as absolute fatwa. Always consult with certified scholars.
            </p>
          </div>
        </div>
      </div>
      
      <div style={{ marginTop: '2rem', padding: '1.5rem', background: 'rgba(255,255,255,0.05)', borderRadius: '8px', fontSize: '0.85rem', color: 'var(--color-text-muted)' }}>
        <strong>Disclaimer:</strong> This report is generated by an AI-powered Sharia analysis engine based on published fatwas and scholarly opinions. It is for informational purposes only. Consult a qualified Islamic finance scholar for final rulings.
      </div>
      
      </div> {/* Close pdf-content div */}
    </div>
  );
}
