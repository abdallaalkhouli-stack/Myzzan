"use client";

import { useState } from 'react';
import { supabase } from '../../lib/supabase';
import Link from 'next/link';

export default function Signup() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [msg, setMsg] = useState('');

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setMsg('Creating account...');
    
    // 1. Supabase Auth Signup
    const { data, error } = await supabase.auth.signUp({ email, password });
    
    if (error) {
      setMsg(error.message);
      return;
    }

    if (data.user) {
      // 2. We simulate inserting into the users table and generating an API key
      // In a real app, you'd use a Supabase Edge Function or a Postgres Trigger
      // on auth.users to do this securely, but we'll simulate the client call.
      
      const newKey = 'sk_live_' + Math.random().toString(36).substr(2, 9) + Math.random().toString(36).substr(2, 9);
      
      const { error: userErr } = await supabase.from('users').insert({
        id: data.user.id,
        email: email,
        tier: 'FREE'
      });

      if (!userErr) {
        await supabase.from('api_keys').insert({
          user_id: data.user.id,
          key_hash: newKey, // Usually you'd hash this
          limit_per_day: 10
        });
      }
      
      setMsg('Account created successfully! Redirecting to dashboard...');
      setTimeout(() => window.location.href = '/dashboard', 1500);
    }
  };

  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh', background: 'var(--color-bg)' }}>
      <div className="glass-panel" style={{ width: '100%', maxWidth: '400px', padding: '3rem 2rem', textAlign: 'center' }}>
        <h1 style={{ fontSize: '1.5rem', marginBottom: '2rem' }}>Sign up to HalalData</h1>
        
        <form onSubmit={handleSignup} style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem', textAlign: 'left' }}>
          <div>
            <label style={{ display: 'block', marginBottom: '0.5rem', fontSize: '0.9rem', color: 'var(--color-text-muted)' }}>Email Address</label>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)} required style={{ width: '100%', padding: '0.8rem 1rem', borderRadius: '8px', border: '1px solid var(--color-border)', background: 'rgba(0,0,0,0.2)', color: 'var(--color-text-main)', outline: 'none' }} />
          </div>
          <div>
            <label style={{ display: 'block', marginBottom: '0.5rem', fontSize: '0.9rem', color: 'var(--color-text-muted)' }}>Password</label>
            <input type="password" value={password} onChange={e => setPassword(e.target.value)} required style={{ width: '100%', padding: '0.8rem 1rem', borderRadius: '8px', border: '1px solid var(--color-border)', background: 'rgba(0,0,0,0.2)', color: 'var(--color-text-main)', outline: 'none' }} />
          </div>
          {msg && <div style={{ color: 'var(--color-primary)', fontSize: '0.9rem' }}>{msg}</div>}
          <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '1rem', textAlign: 'center' }}>
            Create Account
          </button>
        </form>
        
        <p style={{ marginTop: '2rem', fontSize: '0.9rem', color: 'var(--color-text-muted)' }}>
          Already have an account? <Link href="/login" style={{ color: 'var(--color-primary)' }}>Log in</Link>
        </p>
      </div>
    </div>
  );
}
