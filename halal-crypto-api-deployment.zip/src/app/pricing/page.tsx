"use client";

import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

export default function Pricing() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    async function checkUser() {
      const { data: { session } } = await supabase.auth.getSession();
      if (session) setUser(session.user);
    }
    checkUser();
  }, []);

  const handleCheckout = async (tier: string) => {
    if (!user) {
      router.push('/login');
      return;
    }
    
    setLoading(true);
    try {
      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tier, userId: user.id, email: user.email })
      });
      const data = await res.json();
      if (data.url) {
        window.location.href = data.url; // Redirect to Stripe Checkout
      } else {
        alert(data.error || 'Checkout failed');
      }
    } catch (err) {
      alert('An error occurred during checkout.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <header className="header">
        <div className="container header-content">
          <Link href="/" className="logo">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="url(#paint0_linear)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M2 17L12 22L22 17" stroke="url(#paint1_linear)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M2 12L12 17L22 12" stroke="url(#paint2_linear)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            HalalData
          </Link>
          <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
            {user ? (
               <Link href="/dashboard" className="btn btn-outline">Dashboard</Link>
            ) : (
              <>
                <Link href="/login" className="btn btn-outline">Log in</Link>
                <Link href="/signup" className="btn btn-primary">Sign up</Link>
              </>
            )}
          </div>
        </div>
      </header>

      <main className="container" style={{ paddingTop: '6rem', paddingBottom: '6rem', textAlign: 'center' }}>
        <h1 style={{ fontSize: '3rem', marginBottom: '1rem' }}>Transparent Pricing</h1>
        <p style={{ fontSize: '1.2rem', color: 'var(--color-text-muted)', marginBottom: '4rem' }}>
          Choose the plan that fits your platform's needs. Upgrade or downgrade at any time.
        </p>

        <div className="grid">
          {/* FREE TIER */}
          <div className="feature-card glass-panel pricing-card">
            <h3>Free</h3>
            <div className="price">$0<span>/mo</span></div>
            <p>For individuals and testing.</p>
            <ul className="pricing-features">
              <li>10 coin checks per day</li>
              <li>No API key</li>
              <li>Access to top 20 coins only</li>
              <li>No PDF export</li>
            </ul>
            {user ? (
              <button disabled className="btn btn-outline" style={{ width: '100%', opacity: 0.5 }}>Current Plan</button>
            ) : (
              <Link href="/signup" className="btn btn-outline" style={{ width: '100%', display: 'block' }}>Sign Up Free</Link>
            )}
          </div>

          {/* PRO TIER */}
          <div className="feature-card glass-panel pricing-card" style={{ transform: 'scale(1.05)', borderColor: 'var(--color-primary)', position: 'relative' }}>
            <div style={{ position: 'absolute', top: 0, left: '50%', transform: 'translate(-50%, -50%)', background: 'var(--color-primary)', color: '#000', padding: '0.2rem 1rem', borderRadius: '12px', fontSize: '0.8rem', fontWeight: 'bold' }}>MOST POPULAR</div>
            <h3>Pro</h3>
            <div className="price">$29<span>/mo</span></div>
            <p>For active traders and developers.</p>
            <ul className="pricing-features">
              <li>Unlimited coin checks</li>
              <li>Personal API key</li>
              <li>Access to all 50 coins</li>
              <li>PDF export per coin</li>
              <li>Full reasoning breakdown</li>
            </ul>
            <button onClick={() => handleCheckout('PRO')} disabled={loading} className="btn btn-primary" style={{ width: '100%' }}>
              {loading ? 'Processing...' : 'Upgrade to Pro'}
            </button>
          </div>

          {/* ENTERPRISE TIER */}
          <div className="feature-card glass-panel pricing-card">
            <h3>Enterprise</h3>
            <div className="price">$199<span>/mo</span></div>
            <p>For institutions and exchanges.</p>
            <ul className="pricing-features">
              <li>Everything in Pro</li>
              <li>White label API</li>
              <li>Bulk PDF export (full 50 coin report)</li>
              <li>Custom certification reports</li>
              <li>Priority support badge</li>
            </ul>
            <button onClick={() => handleCheckout('ENTERPRISE')} disabled={loading} className="btn btn-outline" style={{ width: '100%' }}>
              {loading ? 'Processing...' : 'Upgrade to Enterprise'}
            </button>
          </div>
        </div>
      </main>
    </>
  );
}
